# Enterprise-Grade RAG Platform

A full-stack retrieval-augmented generation (RAG) platform built with a FastAPI backend, Next.js frontend, MongoDB storage, and Mistral-powered AI search.

## Overview

This repository delivers a deployable enterprise knowledge platform with:

- Authenticated document upload and management
- Semantic search and chat-based question answering
- Contextual answer citations with transparency
- Prompt injection detection and security logging
- Analytics, feedback, and audit dashboards
- Local Docker Compose and cloud deployment support

## Current Configuration

The backend is configured to use a single LLM provider:

- `Mistral` as the only active model provider
- `backend/runtime.txt` pins Python to `3.13`
- No fallback provider chain is required in production

## Repository Structure

```text
backend/
  app/
    api/v1/routes/
    core/
    db/
    models/
    schemas/
    services/
    workers/
  tests/
frontend/
  app/
  components/
  lib/
  styles/
docs/
infra/
```

## Quick Start

1. Copy `.env.example` to `.env`.
2. Set `MISTRAL_API_KEY` and `MONGO_URI`.
3. Install backend dependencies:

```bash
cd backend
python -m pip install -r requirements.txt
```

4. Install frontend dependencies:

```bash
cd ../frontend
npm install
```

5. Run services locally:

```bash
docker compose up --build
```

6. Access the application:

- Frontend: `http://localhost:3000`
- Backend: `http://localhost:8000`

## Environment Variables

Key variables are documented in `.env.example` and include:

- `MISTRAL_API_KEY`
- `MISTRAL_MODEL`
- `MONGO_URI`
- `SECRET_KEY`
- `NEXT_PUBLIC_API_BASE_URL`

## Documentation

The project now includes expanded documentation to support development, deployment, and submission.

- `docs/Project_Documentation.md`
- `docs/System_Architecture.md`
- `docs/User_Manual.md`
- `docs/Deployment_Guide.md`
- `docs/Prompt_Document.md`
- `docs/Presentation_Content.md`
- `docs/Final_Submission_Checklist.md`
- `screenshots/SCREENSHOT_CHECKLIST.md`

## Deployment

### Local deploy

```bash
docker compose up --build
```

### Cloud deploy

- Render backend configured in `infra/render.yaml`
- Frontend is Vercel-ready with `frontend/next.config.ts`
- Use `backend/runtime.txt` to keep Python 3.13

## Notes

- The current vector layer is an in-memory semantic search store in `backend/app/db/vector.py`.
- Production-grade vector storage should replace this with a dedicated vector database.
- Prompt injection detection is enforced by `backend/app/services/rag.py`.

## API Endpoints

- OpenAPI schema: `http://localhost:8000/api/v1/openapi.json`
- Swagger UI: `http://localhost:8000/docs`

## License

This repository includes an MIT license for open reuse.
